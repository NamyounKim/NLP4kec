#package check & install & load
libraryList <- c("dplyr","stringi","caret","reshape","randomForest","lubridate","ggplot2","psych","doParallel")

for(lib in libraryList){
  package.checking <- find.package(lib,quiet=TRUE)
  if(length(package.checking) == 0){
    install.packages(lib)
  }
}
require(dplyr)
require(stringi)
require(caret)
require(reshape)
require(lubridate)
require(randomForest)
require(e1071)
require(ggplot2)
require(psych)
require(doParallel)

registerDoParallel()


accountML <- subset(account, select=c("CONTRACT_LINE_ID",
                                      "CUSTOMER_ID",
                                      "UNIT",
                                      "TEAM",
                                      "BILL_NAME",
                                      "CENTER_NAME",
                                      "CUSTOMER_TYPE",
                                      "MONTHLY_FEE",
                                      "BANK_CARD_NAME",
                                      "PAYMENT_DAY",
                                      "PAYMENT_TYPE",
                                      "contract",
                                      "install",
                                      "collection",
                                      "maintanence",
                                      "product",
                                      "conversion",
                                      "sell",
                                      "cancle",
                                      "category",
                                      "callSum",
                                      "useDay",
                                      "useMonth",
                                      "CONTRACT_STATUS"))

accountML <- subset(accountML, CONTRACT_STATUS %in% c("정상","해지완료"))
accountML$CONTRACT_STATUS <- factor(accountML$CONTRACT_STATUS)
accountML <- na.omit(accountML)
accountML <- accountML[accountML$useDay >0,]
accountML <- accountML[accountML$CUSTOMER_TYPE %in% "고객",]

selectVariable <- function(data) {
  selected <- c(
    #"UNIT",
    #"TEAM",
    #"BILL_NAME",
    #"CENTER_NAME",
    "MONTHLY_FEE",
    "BANK_CARD_NAME",
    "PAYMENT_DAY",
    "PAYMENT_TYPE",
    "contract",
    "install",
    "collection",
    "maintanence",
    "product",
    "conversion",
    "sell",
    #"cancle",
    "category",
    "callSum",
    "useDay",
    "useMonth"
  )
  return(data[,selected])
}

cvtrain <- trainControl(method="cv", number=5)
grid <- data.frame(mtry=c(5,10,15))

for(index_i in unique(accountML$category)){
  train_s <- accountML[(accountML$category == index_i),]
  
  rf <- train(x=selectVariable(train_s), y=train_s$CONTRACT_STATUS, method="parRF",
              trControl=cvtrain,
              tuneGrid=grid,
              ntree=100,
              metric="Kappa",
              importance=TRUE
              #preProc=c("center", "scale")
  )
  print(index_i)
  print(rf)
  print(varImp(rf))
}


