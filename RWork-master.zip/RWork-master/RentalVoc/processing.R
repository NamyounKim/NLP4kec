library(RODBC)
library(RODBCext)
library(reshape)
library(dplyr)
library(ggplot2)
library(lattice)
library(arules)
library(stringi)
library(stringr)

### Font Setting ###
# library(extrafont)
# font_import()
# fonts() --> 사용가능 폰트 확인
# loadfonts()

conn <- odbcConnect('ccaMart',uid='trendtracker',pwd='#tt1234')

query <- "SELECT CONTRACT_LINE_ID, CUSTOMER_ID, UNIT, TEAM, BILL_NAME, CENTER_NAME, PRODUCT_GROUP, MODEL_NAME, CONTRACT_DATE, CANCEL_DATE, CANCEL_REASON_1, CANCEL_REASON_2, CONTRACT_STATUS, CUSTOMER_TYPE, ZIP_CODE, MONTHLY_FEE, BANK_CARD_NAME, PAYMENT_DAY, PAYMENT_TYPE
FROM ccadb.t_rtl_rental_account;"

query2 <- "select CALL_NO, CREATION_DATE, CONTRACT_LINE_ID, CUSTOMER_ID, CALL_TYPE, CALL_DETAIL_1, CALL_DETAIL_2
from t_rtl_call_hist_2
where CALLS in ('I/B');"

account <- sqlQuery(conn, query)
callHis <- sqlQuery(conn, query2)
callCount <- cast(callHis, CONTRACT_LINE_ID ~ CALL_TYPE, length)
colnames(callCount) <- c("CONTRACT_LINE_ID", "contract", "install","collection" , "maintanence", "product", "conversion", "sell", "cancle")

#model category load
modelCategory <- read.csv(file="./model_category.csv")
colnames(modelCategory)<- c("group","category","modelName")

account <- merge(account, callCount, by.x="CONTRACT_LINE_ID", by.y = "CONTRACT_LINE_ID")
account <- merge(account, modelCategory, by.x = "MODEL_NAME", by.y = "modelName")
account <- subset(account, select = c(-group))
account$callSum <- apply(account[,20:27],1,sum)

#Date diff
account$contractDate <- as.Date(as.character(account$CONTRACT_DATE),"%Y%m%d")
account$cancelDate <- as.Date(as.character(account$CANCEL_DATE),"%Y%m%d")
account$useDay <- ifelse(account$CONTRACT_STATUS=='해지완료', as.integer(account$cancelDate - account$contractDate), as.integer(as.Date("20151231","%Y%m%d") - account$contractDate))
account$useMonth <- as.integer(account$useDay / 30)

#정상 or 해지완료
accountYN <- account[account$CONTRACT_STATUS %in% c("정상", "해지완료"),]
accountYN <- accountYN %>% group_by(CONTRACT_STATUS, PAYMENT_TYPE, category) %>% summarise(count=length(CONTRACT_LINE_ID))
accountYN <- accountYN[accountYN$count<30000,]

# 해지고객 중 타 제품으로 변경한 고객중 사용개월수가 1개월 미만인 고객 추출
account1M <- account[account$useMonth %in% c(0),]



#Call History change to Transactin Data format
callHistory <- callHis[!is.na(callHis$CONTRACT_LINE_ID),]
smallCallHis <- subset(callHistory, select=c(CONTRACT_LINE_ID, CALL_DETAIL_1, CALL_DETAIL_2))
smallCallHis <- subset(smallCallHis, CALL_DETAIL_2!="컨버전")
smallCallHis <- subset(smallCallHis, CALL_DETAIL_2!="제품변경(자사)")
smallCallHis <- merge(smallCallHis, account1M, by.x="CONTRACT_LINE_ID", by.y="CONTRACT_LINE_ID")
smallCallHis <- subset(smallCallHis, select=c(CONTRACT_LINE_ID, CALL_DETAIL_1, CALL_DETAIL_2, CONTRACT_STATUS))

cancelCallHis <- subset(smallCallHis, smallCallHis$CONTRACT_STATUS=="해지완료", select=c(CONTRACT_LINE_ID, CALL_DETAIL_1))
cancelCallHis2 <- subset(smallCallHis, smallCallHis$CONTRACT_STATUS=="해지완료", select=c(CONTRACT_LINE_ID, CALL_DETAIL_2))
okCallHis <- subset(smallCallHis, smallCallHis$CONTRACT_STATUS=="정상", select=c(CONTRACT_LINE_ID, CALL_DETAIL_1))


#해지완료 고객 중 자사변경인 고객 리스트 구하기
temp <- subset(smallCallHis, CALL_DETAIL_2 !="제품변경(자사)")
temp2 <- merge(temp, account, by.x="CONTRACT_LINE_ID", by.y="CONTRACT_LINE_ID")
temp3 <- subset(temp2, temp2$CONTRACT_STATUS == "해지완료")
cancelReturn <- unique(temp3$CONTRACT_LINE_ID)
accountCR <- account[account$CONTRACT_LINE_ID %in% cancelReturn,]
accountCNR <- account[account$CONTRACT_LINE_ID %in% cancelReturn,]



### Apriori 분석 ###
makeTransaction <- function(inputData){
  temp <- split(inputData[,"CALL_DETAIL_1"],inputData[,"CONTRACT_LINE_ID"])
  
  #Duplication Item remove
  listData <- list()
  for (i in 1:length(temp)) {
    listData[[i]] <- as.character(temp[[i]][!duplicated(temp[[i]])])
  }
  tranData <- as(listData,"transactions")
  
  return(tranData)
}

TcancelCallHis <- makeTransaction(cancelCallHis)
TokCallHis <- makeTransaction(okCallHis)

TcancelCallHis2 <- makeTransaction(cancelCallHis)
TokCallHis2 <- makeTransaction(okCallHis)

TcancelRul1M <- apriori(data=TCallHist1M , parameter = list(support=0.001, confidence=0.001, maxlen=3))

TcancelRule <- apriori(data=TcancelCallHis, parameter = list(support=0.001, confidence=0.001, maxlen=3))
defenceRule <- subset(TcancelRul1M, items %pin% "해지접수")
inspect(sort(defenceRule, by=c("confidence","lift")))
defenceRuleDf <- as(defenceRule, "data.frame")
defenceRuleDf$lhs <- noquote(trimws(str_split_fixed(as.character(defenceRuleDf$rules),"=>",2)[,1]))
defenceRuleDf$rhs <- noquote(trimws(str_split_fixed(as.character(defenceRuleDf$rules),"=>",2)[,2]))

temp <- subset(defenceRuleDf, grepl("해지접수",rhs))
temp <- subset(temp, grepl("3대이슈",lhs))
temp[order(-temp$confidence),]

TokRule <- apriori(data=TokCallHis, parameter = list(support=0.01, confidence=0.01, maxlen=2))

TcancelRule2 <- apriori(data=TcancelCallHis2, parameter = list(support=0.001, confidence=0.001, maxlen=3))
subsetRule <- subset(TcancelRule2, items %pin% "정책")
inspect(sort(subsetRule, by="lift"))
TokRule2 <- apriori(data=TokCallHis2, parameter = list(support=0.01, confidence=0.01, maxlen=2))

save.image("~/TextPrism/RSource/RentalVoc/RentalVoc.RData")

odbcClose(conn)
