
tiTest <- read.csv(file = "./3_titanic/test.csv")
tiTrain <- read.csv(file = "./3_titanic/train.csv")
