install.packages("installr")
library(installr)
updateR(F, T, T, F, T, F, T)
